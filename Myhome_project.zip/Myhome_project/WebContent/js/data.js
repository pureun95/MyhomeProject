//inc > data.js 파일 생성

var list = [
	{
		"name": "한독빌딩",
		"position": { "lat" : 37.499330, "lng" : 127.033181 }
	}, 
	{
		"name": "역삼역",
		"position": { "lat" : 37.500089, "lng" : 127.035399 }
	}, 
	{
		"name": "롯데리아",
		"position": { "lat" : 37.498556, "lng" : 127.030443 }
	}, 
	{
		"name": "국민은행",
		"position": { "lat" : 37.499707, "lng" : 127.032141 }
	}, 
	{
		"name": "신한은행",
		"position": { "lat" : 37.499944, "lng" : 127.035494 }
	}, 
	{
		"name": "파리바게뜨",
		"position": { "lat" : 37.499378, "lng" : 127.034302 }
	}, 
	{
		"name": "뚜레쥬르",
		"position": { "lat" : 37.499097, "lng" : 127.034532 }
	}, 
	{
		"name": "세븐일레븐",
		"position": { "lat" : 37.499028, "lng" : 127.033160 }
	}, 
	{
		"name": "CU",
		"position": { "lat" : 37.498798, "lng" : 127.033485 }
	}, 
	{
		"name": "세븐스프링스",
		"position": { "lat" : 37.498982, "lng" : 127.032267 }
	}
];

















