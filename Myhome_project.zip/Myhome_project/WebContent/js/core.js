//core.js

function sum(a, b) {
    return a + b;
}

function substract(a, b) {
    return a - b;
}