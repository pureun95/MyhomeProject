$("#upload-property").hover(function() {
		$("#main-img1").css("background-image", "url('../image/mypage/upload2.png')");
   	}, function() {
        $("#main-img1").css("background-image", "url('../image/mypage/upload.png')");
    });


  $("#matching-property").hover(function() {
            $("#main-img2").css("background-image", "url('../image/mypage/matching2.png')");
       }, function() {
            $("#main-img2").css("background-image", "url('../image/mypage/matching.png')");
       });
       
       $("#contract").hover(function() {
            $("#main-img3").css("background-image", "url('../image/mypage/contract2.png')");
       }, function() {
            $("#main-img3").css("background-image", "url('../image/mypage/contract.png')");
       });
       
       $("#edit-info").hover(function() {
            $("#main-img4").css("background-image", "url('../image/mypage/info2.png')");
       }, function() {
            $("#main-img4").css("background-image", "url('../image/mypage/info.png')");
  	});
  