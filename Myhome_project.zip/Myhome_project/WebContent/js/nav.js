
       /* $(".li-list").hover(function() {
            $(this).addClass("li-list-hover");
        }, function() {
            $(this).removeClass("li-list-hover");
        });

        $("#nav1-content1").hover(function() {
            $("#myupload").css("color", "#f1acac");
        }, function() {
            $("#myupload").css("color", "");
        });

        $("#nav1-content2").hover(function() {
            $("#mymatching").css("color", "#f1acac");
        }, function() {
            $("#mymatching").css("color", "");
        });

        $("#nav1-content3").hover(function() {
            $("#mycontract").css("color", "#f1acac");
        }, function() {
            $("#mycontract").css("color", "");
        });

        $("#nav1-content4").hover(function() {
            $("#myinfo").css("color", "#f1acac");
        }, function() {
            $("#myinfo").css("color", "");
        });
        */

